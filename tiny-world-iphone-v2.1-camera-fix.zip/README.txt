Tiny World — V2.1 Camera / Terrain Fix

FIXED FROM THE IPHONE SCREENSHOTS
- Terrain no longer morphs or stretches when panning near the world boundary.
- Settlers, buildings, particles and terrain now use the exact same camera transform.
- Retina / iPhone devicePixelRatio is accounted for correctly.
- Pinch zoom is now aligned with the visual map.
- Camera is constrained to valid world bounds.
- If the viewport is larger than the generated world, the world stays centered instead of stretching.
- Outside-map space is rendered as ocean rather than stretching the terrain texture.

This keeps all V2 visual upgrades.

DEPLOY
Upload this ZIP as the next deployment for your existing static-assets Worker.

If the old build remains cached:
1. Open the Worker URL once in Safari.
2. Reload.
3. Fully close the installed Tiny World app.
4. Reopen it.
